﻿namespace Car_Rental_Project
{
    partial class EmpVehiclesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvVehicles = new System.Windows.Forms.DataGridView();
            this.btnAddVehicle = new System.Windows.Forms.Button();
            this.btnRemVehicle = new System.Windows.Forms.Button();
            this.btnEditVehicle = new System.Windows.Forms.Button();
            this.lblVehicleReg = new System.Windows.Forms.Label();
            this.lblVehicleBrand = new System.Windows.Forms.Label();
            this.lblVehicleYear = new System.Windows.Forms.Label();
            this.lblVehicleColor = new System.Windows.Forms.Label();
            this.lblVehicleMake = new System.Windows.Forms.Label();
            this.lblGasType = new System.Windows.Forms.Label();
            this.txtRegNo = new System.Windows.Forms.TextBox();
            this.gbxVehicleInfo = new System.Windows.Forms.GroupBox();
            this.txtVehicleGasType = new System.Windows.Forms.TextBox();
            this.txtVehicleMake = new System.Windows.Forms.TextBox();
            this.txtVehicleColor = new System.Windows.Forms.TextBox();
            this.txtVehicleYear = new System.Windows.Forms.TextBox();
            this.txtVehicleBrand = new System.Windows.Forms.TextBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVehicles)).BeginInit();
            this.gbxVehicleInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvVehicles
            // 
            this.dgvVehicles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVehicles.Location = new System.Drawing.Point(534, 44);
            this.dgvVehicles.Name = "dgvVehicles";
            this.dgvVehicles.RowTemplate.Height = 25;
            this.dgvVehicles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvVehicles.Size = new System.Drawing.Size(477, 303);
            this.dgvVehicles.TabIndex = 1;
            // 
            // btnAddVehicle
            // 
            this.btnAddVehicle.Location = new System.Drawing.Point(534, 375);
            this.btnAddVehicle.Name = "btnAddVehicle";
            this.btnAddVehicle.Size = new System.Drawing.Size(144, 45);
            this.btnAddVehicle.TabIndex = 2;
            this.btnAddVehicle.Text = "Add Vehicle";
            this.btnAddVehicle.UseVisualStyleBackColor = true;
            this.btnAddVehicle.Click += new System.EventHandler(this.btnAddVehicle_Click);
            // 
            // btnRemVehicle
            // 
            this.btnRemVehicle.Location = new System.Drawing.Point(867, 375);
            this.btnRemVehicle.Name = "btnRemVehicle";
            this.btnRemVehicle.Size = new System.Drawing.Size(144, 45);
            this.btnRemVehicle.TabIndex = 3;
            this.btnRemVehicle.Text = "Remove Vehicle";
            this.btnRemVehicle.UseVisualStyleBackColor = true;
            // 
            // btnEditVehicle
            // 
            this.btnEditVehicle.Location = new System.Drawing.Point(704, 375);
            this.btnEditVehicle.Name = "btnEditVehicle";
            this.btnEditVehicle.Size = new System.Drawing.Size(144, 45);
            this.btnEditVehicle.TabIndex = 4;
            this.btnEditVehicle.Text = "Edit Vehicle";
            this.btnEditVehicle.UseVisualStyleBackColor = true;
            // 
            // lblVehicleReg
            // 
            this.lblVehicleReg.AutoSize = true;
            this.lblVehicleReg.Location = new System.Drawing.Point(26, 47);
            this.lblVehicleReg.Name = "lblVehicleReg";
            this.lblVehicleReg.Size = new System.Drawing.Size(117, 15);
            this.lblVehicleReg.TabIndex = 0;
            this.lblVehicleReg.Text = "Registration Number";
            // 
            // lblVehicleBrand
            // 
            this.lblVehicleBrand.AutoSize = true;
            this.lblVehicleBrand.Location = new System.Drawing.Point(26, 105);
            this.lblVehicleBrand.Name = "lblVehicleBrand";
            this.lblVehicleBrand.Size = new System.Drawing.Size(78, 15);
            this.lblVehicleBrand.TabIndex = 1;
            this.lblVehicleBrand.Text = "Vehicle Brand";
            // 
            // lblVehicleYear
            // 
            this.lblVehicleYear.AutoSize = true;
            this.lblVehicleYear.Location = new System.Drawing.Point(26, 159);
            this.lblVehicleYear.Name = "lblVehicleYear";
            this.lblVehicleYear.Size = new System.Drawing.Size(69, 15);
            this.lblVehicleYear.TabIndex = 2;
            this.lblVehicleYear.Text = "Vehicle Year";
            // 
            // lblVehicleColor
            // 
            this.lblVehicleColor.AutoSize = true;
            this.lblVehicleColor.Location = new System.Drawing.Point(26, 217);
            this.lblVehicleColor.Name = "lblVehicleColor";
            this.lblVehicleColor.Size = new System.Drawing.Size(76, 15);
            this.lblVehicleColor.TabIndex = 3;
            this.lblVehicleColor.Text = "Vehicle Color";
            // 
            // lblVehicleMake
            // 
            this.lblVehicleMake.AutoSize = true;
            this.lblVehicleMake.Location = new System.Drawing.Point(26, 282);
            this.lblVehicleMake.Name = "lblVehicleMake";
            this.lblVehicleMake.Size = new System.Drawing.Size(76, 15);
            this.lblVehicleMake.TabIndex = 4;
            this.lblVehicleMake.Text = "Vehicle Make";
            // 
            // lblGasType
            // 
            this.lblGasType.AutoSize = true;
            this.lblGasType.Location = new System.Drawing.Point(26, 344);
            this.lblGasType.Name = "lblGasType";
            this.lblGasType.Size = new System.Drawing.Size(83, 15);
            this.lblGasType.TabIndex = 5;
            this.lblGasType.Text = "Petrol / Diesel ";
            // 
            // txtRegNo
            // 
            this.txtRegNo.Location = new System.Drawing.Point(194, 39);
            this.txtRegNo.Name = "txtRegNo";
            this.txtRegNo.Size = new System.Drawing.Size(238, 23);
            this.txtRegNo.TabIndex = 6;
            // 
            // gbxVehicleInfo
            // 
            this.gbxVehicleInfo.Controls.Add(this.txtVehicleGasType);
            this.gbxVehicleInfo.Controls.Add(this.txtVehicleMake);
            this.gbxVehicleInfo.Controls.Add(this.txtVehicleColor);
            this.gbxVehicleInfo.Controls.Add(this.txtVehicleYear);
            this.gbxVehicleInfo.Controls.Add(this.txtVehicleBrand);
            this.gbxVehicleInfo.Controls.Add(this.txtRegNo);
            this.gbxVehicleInfo.Controls.Add(this.lblGasType);
            this.gbxVehicleInfo.Controls.Add(this.lblVehicleMake);
            this.gbxVehicleInfo.Controls.Add(this.lblVehicleColor);
            this.gbxVehicleInfo.Controls.Add(this.lblVehicleYear);
            this.gbxVehicleInfo.Controls.Add(this.lblVehicleBrand);
            this.gbxVehicleInfo.Controls.Add(this.lblVehicleReg);
            this.gbxVehicleInfo.Location = new System.Drawing.Point(31, 34);
            this.gbxVehicleInfo.Name = "gbxVehicleInfo";
            this.gbxVehicleInfo.Size = new System.Drawing.Size(475, 469);
            this.gbxVehicleInfo.TabIndex = 0;
            this.gbxVehicleInfo.TabStop = false;
            this.gbxVehicleInfo.Text = "Vehicle Information";
            // 
            // txtVehicleGasType
            // 
            this.txtVehicleGasType.Location = new System.Drawing.Point(194, 341);
            this.txtVehicleGasType.Name = "txtVehicleGasType";
            this.txtVehicleGasType.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleGasType.TabIndex = 11;
            // 
            // txtVehicleMake
            // 
            this.txtVehicleMake.Location = new System.Drawing.Point(194, 274);
            this.txtVehicleMake.Name = "txtVehicleMake";
            this.txtVehicleMake.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleMake.TabIndex = 10;
            // 
            // txtVehicleColor
            // 
            this.txtVehicleColor.Location = new System.Drawing.Point(194, 214);
            this.txtVehicleColor.Name = "txtVehicleColor";
            this.txtVehicleColor.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleColor.TabIndex = 9;
            // 
            // txtVehicleYear
            // 
            this.txtVehicleYear.Location = new System.Drawing.Point(194, 159);
            this.txtVehicleYear.Name = "txtVehicleYear";
            this.txtVehicleYear.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleYear.TabIndex = 8;
            // 
            // txtVehicleBrand
            // 
            this.txtVehicleBrand.Location = new System.Drawing.Point(194, 97);
            this.txtVehicleBrand.Name = "txtVehicleBrand";
            this.txtVehicleBrand.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleBrand.TabIndex = 7;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(704, 524);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(144, 45);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "Go Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(627, 439);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(275, 51);
            this.button1.TabIndex = 6;
            this.button1.Text = "Save Vehicle Information to File";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(523, 12);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(115, 26);
            this.btnRefresh.TabIndex = 7;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // EmpVehiclesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 595);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnEditVehicle);
            this.Controls.Add(this.btnRemVehicle);
            this.Controls.Add(this.btnAddVehicle);
            this.Controls.Add(this.dgvVehicles);
            this.Controls.Add(this.gbxVehicleInfo);
            this.Name = "EmpVehiclesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EmpVehiclesForm";
            this.Load += new System.EventHandler(this.EmpVehiclesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVehicles)).EndInit();
            this.gbxVehicleInfo.ResumeLayout(false);
            this.gbxVehicleInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private DataGridView dgvVehicles;
        private Button btnAddVehicle;
        private Button btnRemVehicle;
        private Button btnEditVehicle;
        private Label lblVehicleReg;
        private Label lblVehicleBrand;
        private Label lblVehicleYear;
        private Label lblVehicleColor;
        private Label lblVehicleMake;
        private Label lblGasType;
        private TextBox txtRegNo;
        private GroupBox gbxVehicleInfo;
        private TextBox txtVehicleGasType;
        private TextBox txtVehicleMake;
        private TextBox txtVehicleColor;
        private TextBox txtVehicleYear;
        private TextBox txtVehicleBrand;
        private Button btnBack;
        private Button button1;
        private Button btnRefresh;
    }
}