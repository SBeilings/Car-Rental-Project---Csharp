﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Car_Rental_Project
{
    public partial class EmpVehiclesForm : Form
    {
        public EmpVehiclesForm()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            EmployeeMain curr_menu = new EmployeeMain();
            this.Hide();
            curr_menu.Show();
        }

        private void EmpVehiclesForm_Load(object sender, EventArgs e)
        {
            var slcquery = "SELECT * FROM TBL_VEHICLE";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SB_RENTALS; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvVehicles.ReadOnly = true;
            dgvVehicles.DataSource = ds.Tables[0];
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            var slcquery = "SELECT * FROM TBL_VEHICLE";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SB_RENTALS; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvVehicles.ReadOnly = true;
            dgvVehicles.DataSource = ds.Tables[0];
        }

        private void btnAddVehicle_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtRegNo.Text != "")
                {
                    if (txtVehicleBrand.Text != "")
                    {

                        if (txtVehicleColor.Text != "")
                        {

                            if (txtVehicleGasType.Text != "")
                            {

                                if (txtVehicleMake.Text != "")
                                {

                                    if (txtVehicleYear.Text != "")
                                    {

                                        SqlConnection conn = new SqlConnection();
                                        conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SB_RENTALS ; Integrated Security = SSPI";
                                        conn.Open();

                                        SqlCommand cmdInsert = new SqlCommand("Insert into TBL_VEHICLE(RegNo , Brand, Year, Color, Make, GasType) VALUES ('" + txtRegNo.Text + "', '" + txtVehicleBrand.Text + "', '" + txtVehicleYear.Text + "', '" + txtVehicleColor.Text + "', '" + txtVehicleMake.Text + "', '" + txtVehicleGasType.Text + "')", conn);
                                        int insertedRows = cmdInsert.ExecuteNonQuery();

                                        conn.Close();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
    }
}
