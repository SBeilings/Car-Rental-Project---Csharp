﻿namespace Car_Rental_Project
{
    partial class EmployeeMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVehicles = new System.Windows.Forms.Button();
            this.btnBookings = new System.Windows.Forms.Button();
            this.btnUsers = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.gbxEmployee = new System.Windows.Forms.GroupBox();
            this.btnLogout = new System.Windows.Forms.Button();
            this.gbxEmployee.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnVehicles
            // 
            this.btnVehicles.Location = new System.Drawing.Point(198, 59);
            this.btnVehicles.Name = "btnVehicles";
            this.btnVehicles.Size = new System.Drawing.Size(216, 50);
            this.btnVehicles.TabIndex = 0;
            this.btnVehicles.Text = "Vehicles";
            this.btnVehicles.UseVisualStyleBackColor = true;
            this.btnVehicles.Click += new System.EventHandler(this.btnVehicles_Click);
            // 
            // btnBookings
            // 
            this.btnBookings.Location = new System.Drawing.Point(198, 162);
            this.btnBookings.Name = "btnBookings";
            this.btnBookings.Size = new System.Drawing.Size(216, 50);
            this.btnBookings.TabIndex = 1;
            this.btnBookings.Text = "Manage Bookings";
            this.btnBookings.UseVisualStyleBackColor = true;
            this.btnBookings.Click += new System.EventHandler(this.btnBookings_Click);
            // 
            // btnUsers
            // 
            this.btnUsers.Location = new System.Drawing.Point(198, 261);
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.Size = new System.Drawing.Size(216, 50);
            this.btnUsers.TabIndex = 2;
            this.btnUsers.Text = "View Users";
            this.btnUsers.UseVisualStyleBackColor = true;
            this.btnUsers.Click += new System.EventHandler(this.btnUsers_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(198, 367);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(216, 50);
            this.button4.TabIndex = 3;
            this.button4.Text = "Update Profile Information";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // gbxEmployee
            // 
            this.gbxEmployee.Controls.Add(this.btnVehicles);
            this.gbxEmployee.Controls.Add(this.button4);
            this.gbxEmployee.Controls.Add(this.btnBookings);
            this.gbxEmployee.Controls.Add(this.btnUsers);
            this.gbxEmployee.Location = new System.Drawing.Point(142, 47);
            this.gbxEmployee.Name = "gbxEmployee";
            this.gbxEmployee.Size = new System.Drawing.Size(623, 492);
            this.gbxEmployee.TabIndex = 4;
            this.gbxEmployee.TabStop = false;
            this.gbxEmployee.Text = "Employee Form";
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(789, 488);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(156, 85);
            this.btnLogout.TabIndex = 5;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // EmployeeMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 585);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.gbxEmployee);
            this.Name = "EmployeeMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Backend System";
            this.gbxEmployee.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnVehicles;
        private Button btnBookings;
        private Button btnUsers;
        private Button button4;
        private GroupBox gbxEmployee;
        private Button btnLogout;
    }
}