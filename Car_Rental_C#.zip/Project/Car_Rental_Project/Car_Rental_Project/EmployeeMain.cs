﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Rental_Project
{
    public partial class EmployeeMain : Form
    {
        public EmployeeMain()
        {
            InitializeComponent();
        }

        private void btnVehicles_Click(object sender, EventArgs e)
        {
            EmpVehiclesForm curr_menu = new EmpVehiclesForm();
            this.Hide();
            curr_menu.Show();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Form1 currmenu = new Form1();
            this.Hide();   
            currmenu.Show();   
        }

        private void btnBookings_Click(object sender, EventArgs e)
        {
            frmBookings frmBookings = new frmBookings();
            this.Hide();
            frmBookings.Show();
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            frmUsers frmUsers = new frmUsers(); 
            this.Hide();
            frmUsers.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmUpdateInformation frmUpdateInformation = new frmUpdateInformation(); 
            this.Hide();   
            frmUpdateInformation.Show();    
        }
    }
}
