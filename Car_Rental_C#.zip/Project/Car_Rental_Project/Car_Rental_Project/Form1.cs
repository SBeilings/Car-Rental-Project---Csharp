using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace Car_Rental_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string uname = txtUname.Text;
            string pass = txtPass.Text;
            string returned_pass = "Password does not match!";

            try
            {
                if (uname == "" || pass == "")
                {
                    MessageBox.Show("Username or Password is Blank!");
                }
                else 
                {
                    MessageBox.Show("Please be patient while we check your password");
                    byte[] bytes = Encoding.Default.GetBytes(pass);
                    string hexPass = BitConverter.ToString(bytes);
                    hexPass = hexPass.Replace("-", "");

                    MessageBox.Show("Password encryption complete. Comparing with encrypted password on DB");

                    if (uname.Length > 8)
                    {
                        SqlConnection conn = new SqlConnection();
                        conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SB_RENTALS; Integrated Security = SSPI";
                        conn.Open();
                        SqlCommand cmdSelect = new SqlCommand("SELECT Pass_Word From TBL_USERS WHERE Username = '" + uname + "'", conn);
                        SqlDataReader dr = cmdSelect.ExecuteReader();

                        while (dr.Read())
                        {
                            returned_pass = dr.GetString(0);
                        }

                        dr.Close();
                        conn.Close();

                        if (returned_pass == hexPass)
                        {
                            MessageBox.Show("Password verified!");
                            if (uname.Substring(0, 3) != "CUS")
                            {
                                EmployeeMain curr_menu = new EmployeeMain();
                                this.Hide();
                                curr_menu.Show();
                            }
                            else
                            {
                                frmSBRentalsFrontEnd currmenu = new frmSBRentalsFrontEnd();
                                this.Hide();
                                currmenu.Show();
                            }

                        }
                    }
                    
                }
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            try
            {
                string Name = txtName.Text;
                string Sname = txtSname.Text;
                string Pass = txtNewPass.Text;
                string empType = "CUSTOMER";

                if (Name != "" && Sname != "" && Pass != "")
                {
                    if (Name.Length > 4 && Sname.Length > 4 && Pass.Length > 4)
                    {

                        byte[] bytes = Encoding.Default.GetBytes(Pass);
                        string hexPass = BitConverter.ToString(bytes);
                        hexPass = hexPass.Replace("-", "");

                        string uname = empType.Substring(0, 3) + "_" + Name.Substring(0, 3) + Sname.Substring(0, 3);
                        txtRegUname.Text = uname.ToUpper();
                        uname = txtRegUname.Text;

                        string filename = @"C:\Users\shami\Documents\C#\AccountInformation.txt";
                        using (StreamWriter writer = new StreamWriter(filename))
                        {
                            writer.WriteLine(Name+ " " + Sname + " " + Pass);
                        }

                        SqlConnection conn = new SqlConnection();
                        conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SB_RENTALS ; Integrated Security = SSPI";
                        conn.Open();

                        SqlCommand cmdInsert = new SqlCommand("Insert into TBL_USERS(UserName , FirstName, LastName, Pass_Word, EmployeeType) VALUES ('" + uname + "', '" + Name + "', '" + Sname + "', '" + hexPass + "', '" + empType + "')", conn);
                        int insertedRows = cmdInsert.ExecuteNonQuery();

                        conn.Close();


                    }
                    else
                    {
                        MessageBox.Show("Name , Surname and Password must contain at least 4 characters");
                    }
                }
                else 
                {
                    MessageBox.Show("Name , Surname and Password cannot be blank");
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                MessageBox.Show("Uncaught Error, escalate to System Admin");
            }
        }
    }
}