﻿namespace Car_Rental_Project
{
    partial class frmConfirmBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxConfirm = new System.Windows.Forms.GroupBox();
            this.txtVehicleGasType = new System.Windows.Forms.TextBox();
            this.txtVehicleMake = new System.Windows.Forms.TextBox();
            this.txtColor = new System.Windows.Forms.TextBox();
            this.txtVehicleYear = new System.Windows.Forms.TextBox();
            this.txtVehicleBrand = new System.Windows.Forms.TextBox();
            this.txtReg = new System.Windows.Forms.TextBox();
            this.lblGasType = new System.Windows.Forms.Label();
            this.lblVehicleMake = new System.Windows.Forms.Label();
            this.lblVehicleColor = new System.Windows.Forms.Label();
            this.lblVehicleYear = new System.Windows.Forms.Label();
            this.lblVehicleBrand = new System.Windows.Forms.Label();
            this.lblVehicleReg = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.gbxConfirm.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxConfirm
            // 
            this.gbxConfirm.Controls.Add(this.btnConfirm);
            this.gbxConfirm.Controls.Add(this.dtpTo);
            this.gbxConfirm.Controls.Add(this.label2);
            this.gbxConfirm.Controls.Add(this.dtpFrom);
            this.gbxConfirm.Controls.Add(this.label1);
            this.gbxConfirm.Controls.Add(this.txtVehicleGasType);
            this.gbxConfirm.Controls.Add(this.txtVehicleMake);
            this.gbxConfirm.Controls.Add(this.txtColor);
            this.gbxConfirm.Controls.Add(this.txtVehicleYear);
            this.gbxConfirm.Controls.Add(this.txtVehicleBrand);
            this.gbxConfirm.Controls.Add(this.txtReg);
            this.gbxConfirm.Controls.Add(this.lblGasType);
            this.gbxConfirm.Controls.Add(this.lblVehicleMake);
            this.gbxConfirm.Controls.Add(this.lblVehicleColor);
            this.gbxConfirm.Controls.Add(this.lblVehicleYear);
            this.gbxConfirm.Controls.Add(this.lblVehicleBrand);
            this.gbxConfirm.Controls.Add(this.lblVehicleReg);
            this.gbxConfirm.Location = new System.Drawing.Point(54, 32);
            this.gbxConfirm.Name = "gbxConfirm";
            this.gbxConfirm.Size = new System.Drawing.Size(879, 382);
            this.gbxConfirm.TabIndex = 2;
            this.gbxConfirm.TabStop = false;
            this.gbxConfirm.Text = "Confirm Booking";
            // 
            // txtVehicleGasType
            // 
            this.txtVehicleGasType.Location = new System.Drawing.Point(593, 169);
            this.txtVehicleGasType.Name = "txtVehicleGasType";
            this.txtVehicleGasType.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleGasType.TabIndex = 11;
            this.txtVehicleGasType.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVehicleMake
            // 
            this.txtVehicleMake.Location = new System.Drawing.Point(194, 172);
            this.txtVehicleMake.Name = "txtVehicleMake";
            this.txtVehicleMake.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleMake.TabIndex = 10;
            this.txtVehicleMake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtColor
            // 
            this.txtColor.Location = new System.Drawing.Point(194, 107);
            this.txtColor.Name = "txtColor";
            this.txtColor.Size = new System.Drawing.Size(238, 23);
            this.txtColor.TabIndex = 9;
            this.txtColor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVehicleYear
            // 
            this.txtVehicleYear.Location = new System.Drawing.Point(593, 102);
            this.txtVehicleYear.Name = "txtVehicleYear";
            this.txtVehicleYear.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleYear.TabIndex = 8;
            this.txtVehicleYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVehicleBrand
            // 
            this.txtVehicleBrand.Location = new System.Drawing.Point(593, 44);
            this.txtVehicleBrand.Name = "txtVehicleBrand";
            this.txtVehicleBrand.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleBrand.TabIndex = 7;
            this.txtVehicleBrand.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtReg
            // 
            this.txtReg.Location = new System.Drawing.Point(194, 39);
            this.txtReg.Name = "txtReg";
            this.txtReg.Size = new System.Drawing.Size(238, 23);
            this.txtReg.TabIndex = 6;
            this.txtReg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblGasType
            // 
            this.lblGasType.AutoSize = true;
            this.lblGasType.Location = new System.Drawing.Point(499, 172);
            this.lblGasType.Name = "lblGasType";
            this.lblGasType.Size = new System.Drawing.Size(83, 15);
            this.lblGasType.TabIndex = 5;
            this.lblGasType.Text = "Petrol / Diesel ";
            // 
            // lblVehicleMake
            // 
            this.lblVehicleMake.AutoSize = true;
            this.lblVehicleMake.Location = new System.Drawing.Point(26, 180);
            this.lblVehicleMake.Name = "lblVehicleMake";
            this.lblVehicleMake.Size = new System.Drawing.Size(76, 15);
            this.lblVehicleMake.TabIndex = 4;
            this.lblVehicleMake.Text = "Vehicle Make";
            // 
            // lblVehicleColor
            // 
            this.lblVehicleColor.AutoSize = true;
            this.lblVehicleColor.Location = new System.Drawing.Point(26, 115);
            this.lblVehicleColor.Name = "lblVehicleColor";
            this.lblVehicleColor.Size = new System.Drawing.Size(76, 15);
            this.lblVehicleColor.TabIndex = 3;
            this.lblVehicleColor.Text = "Vehicle Color";
            // 
            // lblVehicleYear
            // 
            this.lblVehicleYear.AutoSize = true;
            this.lblVehicleYear.Location = new System.Drawing.Point(499, 110);
            this.lblVehicleYear.Name = "lblVehicleYear";
            this.lblVehicleYear.Size = new System.Drawing.Size(69, 15);
            this.lblVehicleYear.TabIndex = 2;
            this.lblVehicleYear.Text = "Vehicle Year";
            // 
            // lblVehicleBrand
            // 
            this.lblVehicleBrand.AutoSize = true;
            this.lblVehicleBrand.Location = new System.Drawing.Point(499, 47);
            this.lblVehicleBrand.Name = "lblVehicleBrand";
            this.lblVehicleBrand.Size = new System.Drawing.Size(78, 15);
            this.lblVehicleBrand.TabIndex = 1;
            this.lblVehicleBrand.Text = "Vehicle Brand";
            // 
            // lblVehicleReg
            // 
            this.lblVehicleReg.AutoSize = true;
            this.lblVehicleReg.Location = new System.Drawing.Point(26, 47);
            this.lblVehicleReg.Name = "lblVehicleReg";
            this.lblVehicleReg.Size = new System.Drawing.Size(117, 15);
            this.lblVehicleReg.TabIndex = 0;
            this.lblVehicleReg.Text = "Registration Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 250);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 15);
            this.label1.TabIndex = 12;
            this.label1.Text = "From Date:";
            // 
            // dtpFrom
            // 
            this.dtpFrom.Location = new System.Drawing.Point(194, 242);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(200, 23);
            this.dtpFrom.TabIndex = 13;
            // 
            // dtpTo
            // 
            this.dtpTo.Location = new System.Drawing.Point(194, 292);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(200, 23);
            this.dtpTo.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 300);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 15);
            this.label2.TabIndex = 14;
            this.label2.Text = "To Date:";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnConfirm.ForeColor = System.Drawing.Color.Green;
            this.btnConfirm.Location = new System.Drawing.Point(584, 292);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(197, 39);
            this.btnConfirm.TabIndex = 16;
            this.btnConfirm.Text = "Confirm Booking";
            this.btnConfirm.UseVisualStyleBackColor = true;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(774, 487);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(222, 64);
            this.btnBack.TabIndex = 3;
            this.btnBack.Text = "Go Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // frmConfirmBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1060, 598);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.gbxConfirm);
            this.Name = "frmConfirmBooking";
            this.Text = "Confirm Booking";
            this.gbxConfirm.ResumeLayout(false);
            this.gbxConfirm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox gbxConfirm;
        private Button btnConfirm;
        private DateTimePicker dtpTo;
        private Label label2;
        private DateTimePicker dtpFrom;
        private Label label1;
        private TextBox txtVehicleGasType;
        private TextBox txtVehicleMake;
        private TextBox txtColor;
        private TextBox txtVehicleYear;
        private TextBox txtVehicleBrand;
        private TextBox txtReg;
        private Label lblGasType;
        private Label lblVehicleMake;
        private Label lblVehicleColor;
        private Label lblVehicleYear;
        private Label lblVehicleBrand;
        private Label lblVehicleReg;
        private Button btnBack;
    }
}