﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Rental_Project
{
    public partial class frmConfirmBooking : Form
    {
        public frmConfirmBooking()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmUserCarList curr_menu = new frmUserCarList();
            this.Hide();
            curr_menu.Show();

        }
    }
}
