﻿namespace Car_Rental_Project
{
    partial class frmSBRentalsFrontEnd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCarList = new System.Windows.Forms.Button();
            this.btnPass = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.gbxNavigavition = new System.Windows.Forms.GroupBox();
            this.gbxNavigavition.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCarList
            // 
            this.btnCarList.Location = new System.Drawing.Point(132, 128);
            this.btnCarList.Name = "btnCarList";
            this.btnCarList.Size = new System.Drawing.Size(308, 96);
            this.btnCarList.TabIndex = 1;
            this.btnCarList.Text = "Car List";
            this.btnCarList.UseVisualStyleBackColor = true;
            this.btnCarList.Click += new System.EventHandler(this.btnCarList_Click);
            // 
            // btnPass
            // 
            this.btnPass.Location = new System.Drawing.Point(132, 379);
            this.btnPass.Name = "btnPass";
            this.btnPass.Size = new System.Drawing.Size(308, 96);
            this.btnPass.TabIndex = 3;
            this.btnPass.Text = "Update Password";
            this.btnPass.UseVisualStyleBackColor = true;
            this.btnPass.Click += new System.EventHandler(this.btnPass_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(712, 497);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(219, 90);
            this.button2.TabIndex = 4;
            this.button2.Text = "Logout";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // gbxNavigavition
            // 
            this.gbxNavigavition.Controls.Add(this.btnPass);
            this.gbxNavigavition.Controls.Add(this.btnCarList);
            this.gbxNavigavition.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.gbxNavigavition.Location = new System.Drawing.Point(111, 29);
            this.gbxNavigavition.Name = "gbxNavigavition";
            this.gbxNavigavition.Size = new System.Drawing.Size(536, 533);
            this.gbxNavigavition.TabIndex = 5;
            this.gbxNavigavition.TabStop = false;
            this.gbxNavigavition.Text = "Welcome Back";
            // 
            // frmSBRentalsFrontEnd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(955, 611);
            this.Controls.Add(this.gbxNavigavition);
            this.Controls.Add(this.button2);
            this.Name = "frmSBRentalsFrontEnd";
            this.Text = "SB Rentals Home";
            this.gbxNavigavition.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnCarList;
        private Button btnPass;
        private Button button2;
        private GroupBox gbxNavigavition;
    }
}