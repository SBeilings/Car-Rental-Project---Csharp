﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Rental_Project
{
    public partial class frmSBRentalsFrontEnd : Form
    {
        public frmSBRentalsFrontEnd()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 currmenu = new Form1();
            this.Hide();
            currmenu.Show();
        }

        private void btnCarList_Click(object sender, EventArgs e)
        {
            frmUserCarList currmenu = new frmUserCarList();
            this.Hide();
            currmenu.Show();
        }

        private void btnPass_Click(object sender, EventArgs e)
        {
            frmUpdateInformation frmUpdateInformation = new frmUpdateInformation(); 
            this.Hide();
            frmUpdateInformation.Show();    
        }
    }
}
