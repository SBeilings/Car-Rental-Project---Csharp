﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Car_Rental_Project
{
    public partial class frmUpdateInformation : Form
    {
        public frmUpdateInformation()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();  
            this.Hide();
            form1.Show();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txtUname.Text;
                string newpassword = txtnewPass.Text;
                string username_match = "username not found";

                if (username != "")
                {
                    if (newpassword != "")
                    {

                        byte[] bytes = Encoding.Default.GetBytes(newpassword);
                        string hexPass = BitConverter.ToString(bytes);
                        hexPass = hexPass.Replace("-", "");

                        SqlConnection conn = new SqlConnection();
                        conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SB_RENTALS; Integrated Security = SSPI";
                        conn.Open();
                        SqlCommand cmdSelect = new SqlCommand("SELECT UserName From TBL_USERS WHERE Username = '" + username + "'", conn);
                        SqlDataReader dr = cmdSelect.ExecuteReader();

                        while (dr.Read())
                        {
                            username_match = dr.GetString(0);
                        }

                        dr.Close();
                        conn.Close();

                        if (username == username_match)
                        {
                            
                            conn.Open();
                            SqlCommand cmdUpdate = new SqlCommand("Update TBL_USERS SET Pass_Word = '"+ hexPass + "' WHERE UserName = '" + username + "'", conn);
                            int updatedRows = cmdUpdate.ExecuteNonQuery();
                            MessageBox.Show("Password Updated!");
                        }
                        else
                        {
                            MessageBox.Show("Username does not exist!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password cannot be blank!");
                    }
                }
                else 
                {
                    MessageBox.Show("Username cannot be blank!");
                }

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
    }
}
