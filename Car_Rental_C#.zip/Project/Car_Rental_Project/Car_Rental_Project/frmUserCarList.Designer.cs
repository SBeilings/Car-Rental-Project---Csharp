﻿namespace Car_Rental_Project
{
    partial class frmUserCarList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvUserVehicle = new System.Windows.Forms.DataGridView();
            this.gbxVehicleInfo = new System.Windows.Forms.GroupBox();
            this.txtVehicleGasType = new System.Windows.Forms.TextBox();
            this.txtVehicleMake = new System.Windows.Forms.TextBox();
            this.txtColor = new System.Windows.Forms.TextBox();
            this.txtVehicleYear = new System.Windows.Forms.TextBox();
            this.txtVehicleBrand = new System.Windows.Forms.TextBox();
            this.txtReg = new System.Windows.Forms.TextBox();
            this.lblGasType = new System.Windows.Forms.Label();
            this.lblVehicleMake = new System.Windows.Forms.Label();
            this.lblVehicleColor = new System.Windows.Forms.Label();
            this.lblVehicleYear = new System.Windows.Forms.Label();
            this.lblVehicleBrand = new System.Windows.Forms.Label();
            this.lblVehicleReg = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnBookCar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserVehicle)).BeginInit();
            this.gbxVehicleInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvUserVehicle
            // 
            this.dgvUserVehicle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUserVehicle.Location = new System.Drawing.Point(82, 26);
            this.dgvUserVehicle.Name = "dgvUserVehicle";
            this.dgvUserVehicle.RowTemplate.Height = 25;
            this.dgvUserVehicle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUserVehicle.Size = new System.Drawing.Size(708, 243);
            this.dgvUserVehicle.TabIndex = 0;
            // 
            // gbxVehicleInfo
            // 
            this.gbxVehicleInfo.Controls.Add(this.txtVehicleGasType);
            this.gbxVehicleInfo.Controls.Add(this.txtVehicleMake);
            this.gbxVehicleInfo.Controls.Add(this.txtColor);
            this.gbxVehicleInfo.Controls.Add(this.txtVehicleYear);
            this.gbxVehicleInfo.Controls.Add(this.txtVehicleBrand);
            this.gbxVehicleInfo.Controls.Add(this.txtReg);
            this.gbxVehicleInfo.Controls.Add(this.lblGasType);
            this.gbxVehicleInfo.Controls.Add(this.lblVehicleMake);
            this.gbxVehicleInfo.Controls.Add(this.lblVehicleColor);
            this.gbxVehicleInfo.Controls.Add(this.lblVehicleYear);
            this.gbxVehicleInfo.Controls.Add(this.lblVehicleBrand);
            this.gbxVehicleInfo.Controls.Add(this.lblVehicleReg);
            this.gbxVehicleInfo.Location = new System.Drawing.Point(12, 285);
            this.gbxVehicleInfo.Name = "gbxVehicleInfo";
            this.gbxVehicleInfo.Size = new System.Drawing.Size(846, 226);
            this.gbxVehicleInfo.TabIndex = 1;
            this.gbxVehicleInfo.TabStop = false;
            this.gbxVehicleInfo.Text = "Vehicle Information";
            // 
            // txtVehicleGasType
            // 
            this.txtVehicleGasType.Location = new System.Drawing.Point(593, 169);
            this.txtVehicleGasType.Name = "txtVehicleGasType";
            this.txtVehicleGasType.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleGasType.TabIndex = 11;
            this.txtVehicleGasType.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVehicleMake
            // 
            this.txtVehicleMake.Location = new System.Drawing.Point(194, 172);
            this.txtVehicleMake.Name = "txtVehicleMake";
            this.txtVehicleMake.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleMake.TabIndex = 10;
            this.txtVehicleMake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtColor
            // 
            this.txtColor.Location = new System.Drawing.Point(194, 107);
            this.txtColor.Name = "txtColor";
            this.txtColor.Size = new System.Drawing.Size(238, 23);
            this.txtColor.TabIndex = 9;
            this.txtColor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVehicleYear
            // 
            this.txtVehicleYear.Location = new System.Drawing.Point(593, 102);
            this.txtVehicleYear.Name = "txtVehicleYear";
            this.txtVehicleYear.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleYear.TabIndex = 8;
            this.txtVehicleYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVehicleBrand
            // 
            this.txtVehicleBrand.Location = new System.Drawing.Point(593, 44);
            this.txtVehicleBrand.Name = "txtVehicleBrand";
            this.txtVehicleBrand.Size = new System.Drawing.Size(238, 23);
            this.txtVehicleBrand.TabIndex = 7;
            this.txtVehicleBrand.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtReg
            // 
            this.txtReg.Location = new System.Drawing.Point(194, 39);
            this.txtReg.Name = "txtReg";
            this.txtReg.Size = new System.Drawing.Size(238, 23);
            this.txtReg.TabIndex = 6;
            this.txtReg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblGasType
            // 
            this.lblGasType.AutoSize = true;
            this.lblGasType.Location = new System.Drawing.Point(499, 172);
            this.lblGasType.Name = "lblGasType";
            this.lblGasType.Size = new System.Drawing.Size(83, 15);
            this.lblGasType.TabIndex = 5;
            this.lblGasType.Text = "Petrol / Diesel ";
            // 
            // lblVehicleMake
            // 
            this.lblVehicleMake.AutoSize = true;
            this.lblVehicleMake.Location = new System.Drawing.Point(26, 180);
            this.lblVehicleMake.Name = "lblVehicleMake";
            this.lblVehicleMake.Size = new System.Drawing.Size(76, 15);
            this.lblVehicleMake.TabIndex = 4;
            this.lblVehicleMake.Text = "Vehicle Make";
            // 
            // lblVehicleColor
            // 
            this.lblVehicleColor.AutoSize = true;
            this.lblVehicleColor.Location = new System.Drawing.Point(26, 115);
            this.lblVehicleColor.Name = "lblVehicleColor";
            this.lblVehicleColor.Size = new System.Drawing.Size(76, 15);
            this.lblVehicleColor.TabIndex = 3;
            this.lblVehicleColor.Text = "Vehicle Color";
            // 
            // lblVehicleYear
            // 
            this.lblVehicleYear.AutoSize = true;
            this.lblVehicleYear.Location = new System.Drawing.Point(499, 110);
            this.lblVehicleYear.Name = "lblVehicleYear";
            this.lblVehicleYear.Size = new System.Drawing.Size(69, 15);
            this.lblVehicleYear.TabIndex = 2;
            this.lblVehicleYear.Text = "Vehicle Year";
            // 
            // lblVehicleBrand
            // 
            this.lblVehicleBrand.AutoSize = true;
            this.lblVehicleBrand.Location = new System.Drawing.Point(499, 47);
            this.lblVehicleBrand.Name = "lblVehicleBrand";
            this.lblVehicleBrand.Size = new System.Drawing.Size(78, 15);
            this.lblVehicleBrand.TabIndex = 1;
            this.lblVehicleBrand.Text = "Vehicle Brand";
            // 
            // lblVehicleReg
            // 
            this.lblVehicleReg.AutoSize = true;
            this.lblVehicleReg.Location = new System.Drawing.Point(26, 47);
            this.lblVehicleReg.Name = "lblVehicleReg";
            this.lblVehicleReg.Size = new System.Drawing.Size(117, 15);
            this.lblVehicleReg.TabIndex = 0;
            this.lblVehicleReg.Text = "Registration Number";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(495, 528);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(363, 63);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Go Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnBookCar
            // 
            this.btnBookCar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBookCar.ForeColor = System.Drawing.Color.Green;
            this.btnBookCar.Location = new System.Drawing.Point(82, 528);
            this.btnBookCar.Name = "btnBookCar";
            this.btnBookCar.Size = new System.Drawing.Size(324, 63);
            this.btnBookCar.TabIndex = 3;
            this.btnBookCar.Text = "Book Car";
            this.btnBookCar.UseVisualStyleBackColor = true;
            this.btnBookCar.Click += new System.EventHandler(this.btnBookCar_Click);
            // 
            // frmUserCarList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(886, 603);
            this.Controls.Add(this.btnBookCar);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.gbxVehicleInfo);
            this.Controls.Add(this.dgvUserVehicle);
            this.Name = "frmUserCarList";
            this.Text = "Booking Form";
            this.Load += new System.EventHandler(this.frmUserCarList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserVehicle)).EndInit();
            this.gbxVehicleInfo.ResumeLayout(false);
            this.gbxVehicleInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private DataGridView dataGridView1;
        private GroupBox gbxVehicleInfo;
        private TextBox txtVehicleGasType;
        private TextBox txtVehicleMake;
        private TextBox txtColor;
        private TextBox txtVehicleYear;
        private TextBox txtVehicleBrand;
        private TextBox txtReg;
        private Label lblGasType;
        private Label lblVehicleMake;
        private Label lblVehicleColor;
        private Label lblVehicleYear;
        private Label lblVehicleBrand;
        private Label lblVehicleReg;
        private Button btnBack;
        private Button btnBookCar;
        private DataGridView dgvUserVehicle;
    }
}