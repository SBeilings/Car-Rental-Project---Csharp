﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Car_Rental_Project
{
    public partial class frmUserCarList : Form
    {
        public frmUserCarList()
        {
            InitializeComponent();
        }

        private void frmUserCarList_Load(object sender, EventArgs e)
        {
            var slcquery = "SELECT * FROM TBL_VEHICLE";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SB_RENTALS; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvUserVehicle.ReadOnly = true;
            dgvUserVehicle.DataSource = ds.Tables[0];
        }

        private void btnBookCar_Click(object sender, EventArgs e)
        {
            frmConfirmBooking curr_menu = new frmConfirmBooking();
            this.Hide();
            curr_menu.Show();  

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmSBRentalsFrontEnd curr_menu = new frmSBRentalsFrontEnd();
            this.Hide();
            curr_menu.Show();
        }
    }
}
