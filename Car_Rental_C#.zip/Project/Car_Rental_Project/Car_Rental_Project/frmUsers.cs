﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Car_Rental_Project
{
    public partial class frmUsers : Form
    {
        public frmUsers()
        {
            InitializeComponent();
        }

        private void frmUsers_Load(object sender, EventArgs e)
        {
            var slcquery = "SELECT * FROM TBL_USERS";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SB_RENTALS; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvUsers.ReadOnly = true;
            dgvUsers.DataSource = ds.Tables[0];
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            EmployeeMain employeeMain = new EmployeeMain();
            this.Hide();
            employeeMain.Show();
        }
    }
}
