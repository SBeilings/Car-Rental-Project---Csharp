USE [SB_RENTALS]
GO

/****** Object:  Table [dbo].[TBL_USERS]    Script Date: 3/26/2022 11:57:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TBL_USERS](
	[UserName] [varchar](50) NOT NULL,
	[FirstName] [varchar](50) NOT NULL,
	[LastName] [varchar](50) NOT NULL,
	[Pass_Word] [varchar](50) NOT NULL,
	[EmployeeType] [varchar](50) NOT NULL
) ON [PRIMARY]
GO

