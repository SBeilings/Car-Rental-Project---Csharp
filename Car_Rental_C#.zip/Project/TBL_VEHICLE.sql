USE [SB_RENTALS]
GO

/****** Object:  Table [dbo].[TBL_VEHICLE]    Script Date: 3/26/2022 11:57:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TBL_VEHICLE](
	[RegNo] [varchar](50) NOT NULL,
	[Brand] [varchar](50) NOT NULL,
	[Year] [varchar](50) NOT NULL,
	[Color] [varchar](50) NOT NULL,
	[Make] [varchar](50) NOT NULL,
	[GasType] [varchar](50) NOT NULL
) ON [PRIMARY]
GO

